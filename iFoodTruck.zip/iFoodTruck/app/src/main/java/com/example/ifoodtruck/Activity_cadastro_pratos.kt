package com.example.ifoodtruck

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Activity_cadastro_pratos : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_pratos)
    }
}
